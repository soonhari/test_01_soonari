package todo;

public class todoVO {
	private String tododate;
	private String todo;
	
	public String getTododate() {
		return tododate;
	}
	public void setTododate(String tododate) {
		this.tododate = tododate;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
}
