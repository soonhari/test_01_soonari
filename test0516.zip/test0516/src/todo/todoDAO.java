package todo;

import java.sql.*;

public class todoDAO {
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement pstmt;

	public todoDAO() {
		try {
			String dbURL = "jdbc:oracle:thin:@localhost:1521:XE";
			String dbID = "system";
			String dbPassword = "1234";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dbURL,dbID,dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int write(String tododate, String todo) {
		String SQL = "insert into todo_0516 values(?,?)";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, tododate);
			pstmt.setString(2, todo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return -1;
	}
	
}
